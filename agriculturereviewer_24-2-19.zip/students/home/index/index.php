<?php 
include("../../header.php"); 
?>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->  
      <section class="content-header">
      
      <div class="callout callout-info">
        <h4>Welcome 
             <i>   <?php //echo $_SESSION['firstname']." ". $_SESSION['lastname'] ?> ! </h4>
      </div>

 


 
      <!-- /.row -->
  </section>
    <!-- /.content -->
  </div> 



<?php include("../../footer.php"); ?>