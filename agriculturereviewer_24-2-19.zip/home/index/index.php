<?php 
include("../../header.php");
//include("modals.php");

?>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h3>
        Welcome  


               <?php echo $_SESSION['firstname']." ". $_SESSION['lastname'] ?> !</h3>
 




    <!--    <small>Blank example to the fixed layout</small> -->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Welcome Page</a></li>
       
      </ol>
    </section>


  <section class="content">
    <!-- Main content -->

            <div class="box-header">
            
            </div>

      <div class="row">

        <div class="col-md-12">

<center><img src="2.png"  style="width:50%" height = "50%">

<!-- /body -->

        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
  </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->





<?php include("../../footer.php"); ?>